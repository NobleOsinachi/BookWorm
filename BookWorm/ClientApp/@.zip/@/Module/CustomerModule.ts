
import { CustomerComponent } from "../Component/CustomerComponent";
import { FormsModule } from "@angular/forms";
import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";

export class CustomerModule{}