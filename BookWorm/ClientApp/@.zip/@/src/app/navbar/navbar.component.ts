import  {Component} from "@angular/core";

@Component({
    selector: "navbar",
    styleUrls: ["navbar.component.css"],
    templateUrl: "navbar.component.html",
    
})
export class NavbarComponent{
    title: string = "Dev Book Store";
}