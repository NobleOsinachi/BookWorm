import {Component,  OnInit } from "@angular/core";

@Component({
    // selector: 'bs-book-details',     
    templateUrl: 'book-details.component.html',
})
export class BookDetailsComponent implements OnInit{
    ngOnInit(): void {
        
    }
}