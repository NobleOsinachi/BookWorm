import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BooksListComponent } from './books/books-list/books-list.component';
import { BookDetailsComponent } from './books/book-details/book-details.component';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TruncatePipe } from './shared/pipes/truncate.pipe';
import { NavbarComponent } from './navbar/navbar.component';
import { FormsModule } from '@angular/forms';
import { FavoriteComponent } from './favorites/favorite.component';
import { RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { WelcomeComponent } from './del-welcome/welcome.component';

@NgModule({
  /**Declare all COMPONENTS here before using them */
  declarations: [
    NavbarComponent,
    BooksListComponent,
    AppComponent,
    TruncatePipe,
    FavoriteComponent,
    HomeComponent,
    WelcomeComponent
  ],
  imports: [
    FormsModule,
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot([
      { path: 'home', component: HomeComponent },
      { path: 'books', component: BooksListComponent },
      { path: 'books/:id', component: BookDetailsComponent },
      /**Empty string means root index of the app. pathMatch is full whenever using redirection */
      { path: '', redirectTo: 'home', pathMatch: 'full' },
      { path: '**', redirectTo: 'home', pathMatch: 'full' },
    ]),
  ],
  /**Declare all SERVICES here before using them */
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
