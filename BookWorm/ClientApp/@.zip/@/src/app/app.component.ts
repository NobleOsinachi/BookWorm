// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-root',
//   templateUrl: './app.component.html',
//   styleUrls: ['./app.component.css']
// })
// export class AppComponent {
//   title = 'bookworm';
// }



import { Component } from '@angular/core';


@Component({
 // moduleId: module.id,
  selector:"bs-app", //<bs-app>
  templateUrl: "app.component.html",
  styleUrls : ["app.component.css"],

})
export class AppComponent {
  pageTitle:string = "Dev Book Store";
  searchBox:string="";
  hello(){
    alert("Hello CLicked")
  }
  
}