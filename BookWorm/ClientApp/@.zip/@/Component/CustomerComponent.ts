//#region Import statements   

import { Component } from "@angular/core";
import { Customer } from "../Model/Customer";
//#endregion
//#region Attribute Metadata
@Component({
    selector: "customer-ui",
    templateUrl: "../View/Customer.html"
})
//#endregion
//#region  Customer component class exposing the customer model 
export class CustomerComponent {
    CurrentCustomer: Customer = new Customer();


}