// import { Directive, ElementRef, Input, Renderer2 } from '@angular/core';

// @Directive({
//   selector: '[myHighlight]',
// })
// export class HighlightDirective {
//   constructor(el: ElementRef, renderer: Renderer2) {
//     renderer.setElementStyle(el.nativeElement, 'backgroundColor', 'yellow');
//   }
// }
