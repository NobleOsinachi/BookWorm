/*
@Output outputFromChild:EventEmitter<string> = new EventEmitter<string> ;

methodFromChild(){
    this.outputFromChild =   
}

*/